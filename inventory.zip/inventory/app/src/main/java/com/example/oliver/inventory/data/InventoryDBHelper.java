package com.example.oliver.inventory.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "inventory.db";
    public static final int DATABASE_VERSION = 1;
    public static final String DROP_INVENTORY_TABLE = "DROP TABLE " + InventoryContract.TABLE_NAME + ";";
    public static final String CREATE_INVENTORY_TABLE = "CREATE TABLE " + InventoryContract.TABLE_NAME +
            "(" + InventoryContract.COLUMN_INVENTORY_ID + " INTEGER  PRIMARY KEY AUTOINCREMENT" +
            "," + InventoryContract.COLUMN_INVENTORY_PRODUCT_NAME + " TEXT" +
            "," + InventoryContract.COLUMN_INVENTORY_SUPPLIER_NAME + " TEXT" +
            "," + InventoryContract.COLUMN_INVENTORY_PRICE + " INTEGER" +
            "," + InventoryContract.COLUMN_INVENTORY_QUANTITY + " INTEGER"+
            ","+ InventoryContract.COLUMN_INVENTORY_SUPPLIER_PHONE_NUMBER +" INTEGER);";
    public InventoryDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_INVENTORY_TABLE);
    }
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(DROP_INVENTORY_TABLE);
        sqLiteDatabase.execSQL(CREATE_INVENTORY_TABLE);
    }
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}
