package com.example.oliver.inventory;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.example.oliver.inventory.data.InventoryContract;
import com.example.oliver.inventory.data.InventoryDBHelper;

public class MainActivity extends AppCompatActivity {
    InventoryDBHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helper = new InventoryDBHelper(this);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditorActivity.class);
                startActivity(intent);
            }
        });
        displayDatabaseInfo();
    }

    @Override
    protected void onStart() {
        super.onStart();
        displayDatabaseInfo();
    }

    private void displayDatabaseInfo() {
        InventoryDBHelper mDbHelper = new InventoryDBHelper(this);
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + InventoryContract.TABLE_NAME, null);
        try {
            TextView displayView = (TextView) findViewById(R.id.text_view_pet);
            displayView.setText(getString(R.string.header) + cursor.getCount()+"\n");
            int id;
            String productName;
            int productPrice;
            int productQuantity;
            String supplierName;
            int supplierPhone;
            /// get column name
            int idIndex = cursor.getColumnIndex(InventoryContract.COLUMN_INVENTORY_ID);
            int productNameIndex = cursor.getColumnIndex(InventoryContract.COLUMN_INVENTORY_PRODUCT_NAME);
            int productPriceIndex = cursor.getColumnIndex(InventoryContract.COLUMN_INVENTORY_PRICE);
            int productQuantityIndex = cursor.getColumnIndex(InventoryContract.COLUMN_INVENTORY_QUANTITY);
            int supplierNameIndex = cursor.getColumnIndex(InventoryContract.COLUMN_INVENTORY_SUPPLIER_NAME);
            int supplierPhoneIndex = cursor.getColumnIndex(InventoryContract.COLUMN_INVENTORY_SUPPLIER_PHONE_NUMBER);
            displayView.append(getString(R.string.header2)+"\n");
            while (cursor.moveToNext()) {
                id = cursor.getInt(idIndex);
                productName = cursor.getString(productNameIndex);
                productPrice = cursor.getInt(productPriceIndex);
                productQuantity = cursor.getInt(productQuantityIndex);
                supplierName = cursor.getString(supplierNameIndex);
                supplierPhone = cursor.getInt(supplierPhoneIndex);
                displayView.append(id + " " + productName + " " + productPrice + " " + productQuantity + " " + supplierName + " " + supplierPhone + "\n");
            }
        } finally {
            cursor.close();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_catalog, menu);
        return true;
    }

    private void insertDummy() {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(InventoryContract.COLUMN_INVENTORY_PRODUCT_NAME, "lays");
        values.put(InventoryContract.COLUMN_INVENTORY_PRICE, 3);
        values.put(InventoryContract.COLUMN_INVENTORY_QUANTITY, 2);
        values.put(InventoryContract.COLUMN_INVENTORY_SUPPLIER_PHONE_NUMBER, 12132132);
        values.put(InventoryContract.COLUMN_INVENTORY_SUPPLIER_NAME, "saitama");
        db.insert(InventoryContract.TABLE_NAME, null, values);
        displayDatabaseInfo();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_insert_dummy_data:
                insertDummy();
                return true;
            case R.id.action_delete_all_entries:
                deleteAll();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void deleteAll() {
        SQLiteDatabase db = helper.getWritableDatabase();
        db.delete(InventoryContract.TABLE_NAME, null, null);
        displayDatabaseInfo();
    }
}