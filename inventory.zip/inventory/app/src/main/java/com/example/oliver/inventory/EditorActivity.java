package com.example.oliver.inventory;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import com.example.oliver.inventory.data.InventoryContract;
import com.example.oliver.inventory.data.InventoryDBHelper;

public class EditorActivity extends AppCompatActivity {
    //product
    EditText product_Name_ET;
    EditText product_Price_ET;
    EditText product_Quantity_ET;
    //supplier
    EditText supplier_Name_ET;
    EditText supplier_Phone_ET;
    InventoryDBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        db = new InventoryDBHelper(this);
        product_Name_ET = findViewById(R.id.product_name_et);
        product_Price_ET = findViewById(R.id.product_price_tv);
        product_Quantity_ET = findViewById(R.id.product_quantity_et);
        supplier_Name_ET = findViewById(R.id.supplier_name_et);
        supplier_Phone_ET = findViewById(R.id.supplier_phone_et);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    private void insertDummyData() {
        SQLiteDatabase db = this.db.getWritableDatabase();
        ContentValues values = new ContentValues();
        String productName;
        int productPrice = 0;
        int productQuantity = 0;
        String supplierName;
        int supplierPhone = 0;
        productName = product_Name_ET.getText().toString().trim();
        try {
            productPrice = Integer.parseInt(product_Price_ET.getText().toString().trim());
        } catch (Exception e) {

        }
        try {
            productQuantity = Integer.parseInt(product_Quantity_ET.getText().toString().trim());
        } catch (Exception e) {
        }
        supplierName = supplier_Name_ET.getText().toString().trim();
        try {
            supplierPhone = Integer.parseInt(supplier_Phone_ET.getText().toString().trim());
        } catch (Exception e) {
        }
        values.put(InventoryContract.COLUMN_INVENTORY_PRODUCT_NAME, productName);
        values.put(InventoryContract.COLUMN_INVENTORY_PRICE, productPrice);
        values.put(InventoryContract.COLUMN_INVENTORY_QUANTITY, productQuantity);
        values.put(InventoryContract.COLUMN_INVENTORY_SUPPLIER_NAME, supplierName);
        values.put(InventoryContract.COLUMN_INVENTORY_SUPPLIER_PHONE_NUMBER, supplierPhone);
        long id = db.insert(InventoryContract.TABLE_NAME, null, values);
        if (id > 0) {
            Toast.makeText(this, "id+" + id, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Error data is not inserted", Toast.LENGTH_SHORT).show();
        }
    }
    boolean deletedOrNot=true;
    void deleteWithProductName() {
        SQLiteDatabase db = this.db.getWritableDatabase();
        if (!product_Name_ET.getText().toString().equalsIgnoreCase("")) {
            db.execSQL("DELETE FROM " + InventoryContract.TABLE_NAME + " where " + InventoryContract.COLUMN_INVENTORY_PRODUCT_NAME + " = '" + product_Name_ET.getText().toString() + "'");
            deletedOrNot=true;
        } else {
            Toast.makeText(this, "use product name to delete data", Toast.LENGTH_SHORT).show();
            deletedOrNot=false;
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.insert_dummy_data:
                insertDummyData();
                finish();
                return true;
            case R.id.action_delete:
                deleteWithProductName();
                if (deletedOrNot){
                    finish();
                }
                return true;
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}