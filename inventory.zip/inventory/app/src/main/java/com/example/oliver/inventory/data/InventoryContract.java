package com.example.oliver.inventory.data;

import android.provider.BaseColumns;

public final class InventoryContract implements BaseColumns {
    public static final String TABLE_NAME = "inventory";
    public static final String COLUMN_INVENTORY_ID = "_id";
    public static final String COLUMN_INVENTORY_PRODUCT_NAME = "ProductName";
    public static final String COLUMN_INVENTORY_SUPPLIER_NAME = "SupplierName";
    public static final String COLUMN_INVENTORY_PRICE = "Price";
    public static final String COLUMN_INVENTORY_QUANTITY = "Quantity";
    public static final String COLUMN_INVENTORY_SUPPLIER_PHONE_NUMBER = "SupplierPhoneNumber";
}
