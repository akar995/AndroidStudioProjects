package com.example.oliver.nofancymusicapp;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
public class ArtistAdapter extends ArrayAdapter<MusicInfo> {
    public ArtistAdapter(Context context, ArrayList<MusicInfo> art) {
        super(context, 0, art);
    }
    public View getView(int position, View convertView, ViewGroup parent) {
        View listView = convertView;
        if (listView == null) {
            listView = LayoutInflater.from(getContext()).inflate(R.layout.artist_layout_grid_view, parent, false);

        }
        MusicInfo currentArt = getItem(position);
        TextView artText = listView.findViewById(R.id.art_text_view_layout);
        artText.setText(currentArt.getmArtisticName());
        ImageView imageView = listView.findViewById(R.id.art_image_view);
        imageView.setImageResource(currentArt.getmIconImage());
        return listView;
    }
}
